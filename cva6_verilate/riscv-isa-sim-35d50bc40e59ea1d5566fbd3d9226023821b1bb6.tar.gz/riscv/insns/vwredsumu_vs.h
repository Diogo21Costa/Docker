// vwredsum.vs vd, vs2, vs1
VI_VV_ULOOP_WIDE_REDUCTION
({
  vd_0_res += vs2;
})
