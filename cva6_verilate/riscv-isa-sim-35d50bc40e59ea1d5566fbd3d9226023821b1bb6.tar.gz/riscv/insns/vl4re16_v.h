// vl4re16.v vd, (rs1)
VI_LD_WHOLE(uint16);
