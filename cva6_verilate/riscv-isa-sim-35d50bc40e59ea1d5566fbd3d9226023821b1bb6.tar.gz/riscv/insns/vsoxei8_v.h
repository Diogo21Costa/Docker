// vsxei8.v and vsxseg[2-8]ei8.v
VI_ST_INDEX(e8, true);
