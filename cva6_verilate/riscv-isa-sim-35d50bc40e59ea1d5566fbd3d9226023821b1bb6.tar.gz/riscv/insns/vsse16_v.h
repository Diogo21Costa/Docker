// vsse16v and vssseg[2-8]e16.v
VI_ST(i * RS2, fn, uint16);
