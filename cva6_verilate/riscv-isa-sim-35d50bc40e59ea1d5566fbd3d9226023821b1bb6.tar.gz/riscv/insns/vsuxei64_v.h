// vsuxe64.v
VI_ST_INDEX(e64, true);
