// vlxei16.v and vlxseg[2-8]e16.v
VI_LD_INDEX(e16, true);
