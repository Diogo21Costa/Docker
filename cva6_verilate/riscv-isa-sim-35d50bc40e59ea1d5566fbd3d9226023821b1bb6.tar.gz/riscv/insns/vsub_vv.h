// vsub
VI_VV_LOOP
({
  vd = vs2 - vs1;
})
