require_extension('B');
WRITE_RD(sext_xlen((RS1 << 1) + RS2));
