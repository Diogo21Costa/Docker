// vl2e16.v vd, (rs1)
VI_LD_WHOLE(uint16);
