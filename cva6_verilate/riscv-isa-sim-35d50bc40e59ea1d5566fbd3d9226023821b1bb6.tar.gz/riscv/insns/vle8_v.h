// vle8.v and vlseg[2-8]e8.v
VI_LD(0, (i * nf + fn), int8);
