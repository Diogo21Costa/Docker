// vlxe32.v and vlxseg[2-8]ei32.v
VI_LD_INDEX(e32, true);
