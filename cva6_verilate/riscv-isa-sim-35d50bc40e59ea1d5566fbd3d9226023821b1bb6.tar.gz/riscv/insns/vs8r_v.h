// vs8r.v vs3, (rs1)
VI_ST_WHOLE
