// vl2re32.v vd, (rs1)
VI_LD_WHOLE(uint32);
