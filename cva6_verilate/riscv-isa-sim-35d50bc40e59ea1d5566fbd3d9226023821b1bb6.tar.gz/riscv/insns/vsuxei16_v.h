// vsuxe16.v
VI_ST_INDEX(e16, true);
