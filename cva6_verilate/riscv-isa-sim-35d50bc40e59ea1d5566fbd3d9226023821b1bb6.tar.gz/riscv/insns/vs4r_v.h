// vs4r.v vs3, (rs1)
VI_ST_WHOLE
