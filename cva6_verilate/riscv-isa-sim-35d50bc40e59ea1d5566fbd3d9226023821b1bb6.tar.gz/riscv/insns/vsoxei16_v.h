// vsxei16.v and vsxseg[2-8]ei16.v
VI_ST_INDEX(e16, true);
