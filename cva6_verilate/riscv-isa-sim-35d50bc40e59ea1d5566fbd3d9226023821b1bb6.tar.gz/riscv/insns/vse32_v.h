// vse32.v and vsseg[2-8]e32.v
VI_ST(0, (i * nf + fn), uint32);
