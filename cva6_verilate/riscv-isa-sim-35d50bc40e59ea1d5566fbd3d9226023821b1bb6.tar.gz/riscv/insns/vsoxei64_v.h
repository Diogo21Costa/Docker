// vsxei64.v and vsxseg[2-8]ei64.v
VI_ST_INDEX(e64, true);
