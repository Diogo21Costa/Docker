VI_VV_EXT(8, int);
