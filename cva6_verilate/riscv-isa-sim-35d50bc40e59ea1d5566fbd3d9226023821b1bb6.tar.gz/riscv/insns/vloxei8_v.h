// vlxei8.v and vlxseg[2-8]ei8.v
VI_LD_INDEX(e8, true);
