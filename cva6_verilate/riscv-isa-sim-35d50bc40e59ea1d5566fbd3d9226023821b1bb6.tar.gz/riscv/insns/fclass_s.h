require_extension('F');
require_fp;
WRITE_RD(f32_classify(f32(FRS1)));
