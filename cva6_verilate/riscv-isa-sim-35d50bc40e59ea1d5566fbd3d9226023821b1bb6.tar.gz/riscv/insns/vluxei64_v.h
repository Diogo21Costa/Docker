// vlxei64.v and vlxseg[2-8]ei64.v
VI_LD_INDEX(e64, true);

