require_extension('B');
WRITE_RD(RS1 ^ ~RS2);
