// vle32ff.v and vlseg[2-8]e32ff.v
VI_LDST_FF(int32);
