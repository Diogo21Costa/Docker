// vor
VI_VI_LOOP
({
  vd = simm5 | vs2;
})
