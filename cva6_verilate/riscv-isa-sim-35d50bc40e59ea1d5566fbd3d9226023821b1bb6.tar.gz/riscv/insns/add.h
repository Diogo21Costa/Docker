WRITE_RD(sext_xlen(RS1 + RS2));
