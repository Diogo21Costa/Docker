require_extension('B');
WRITE_RD(sext_xlen(RS1 < RS2 ? RS1 : RS2));
