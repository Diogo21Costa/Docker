// vand.vi vd, simm5, vs2, vm
VI_VI_LOOP
({
  vd = simm5 & vs2;
})
