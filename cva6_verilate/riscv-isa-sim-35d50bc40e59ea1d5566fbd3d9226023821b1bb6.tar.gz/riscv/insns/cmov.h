require_extension('B');
WRITE_RD(RS2 ? RS1 : RS3);
