// vsxei32.v and vsxseg[2-8]ei32.v
VI_ST_INDEX(e32, true);
