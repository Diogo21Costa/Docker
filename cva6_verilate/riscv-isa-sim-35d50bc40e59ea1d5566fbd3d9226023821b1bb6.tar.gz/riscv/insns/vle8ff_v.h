// vle8ff.v and vlseg[2-8]e8ff.v
VI_LDST_FF(int8);
