// vl4re64.v vd, (rs1)
VI_LD_WHOLE(uint64);
